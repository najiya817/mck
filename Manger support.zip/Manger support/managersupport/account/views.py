from django.shortcuts import redirect, render
from django.views import View
from .forms import RegForm,LogForm
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages

# Create your views here.
class HomeView(View):
    def get(self,request,*args,**kwargs):
        return render(request,"main_home.html")
    
class RegView(View):
    def get(self,request,*args,**kwargs):
        f=RegForm()
        return render(request,"reg.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=RegForm(data=request.POST)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"user registred succesfully!!!")
            return redirect("h")
        else:
            messages.error(request,"user registration failed!!!!!!!!!")
            return render(request,'reg.html',{"form":form_data})
    
class LogView(View):
    def get(self,request,*args,**kwargs):
        f=LogForm()
        return render(request,"log.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=LogForm(data=request.POST)
        if form_data.is_valid():
            usr=form_data.cleaned_data.get("username")
            pswd=form_data.cleaned_data.get("password")
            user=authenticate(request,username=usr,password=pswd)
            if user:
                login(request,user)
                messages.success(request,"user login succesfully!!!")
                return redirect("mnh")
            else:
                messages.error(request,"user login failed!!!")
                return redirect("h")
        else:
            return render(request,"log.html",{'form':form_data})
    

class lgout(View):
    def get(self,request):
        logout(request)
        return redirect("log")