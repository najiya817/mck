from django.urls import path
from .views import *
urlpatterns=[
    path('mhome/',MHome.as_view(),name="mnh"),
    path('addstf/',AddStaff.as_view(),name="addstf"),
    path('vwstf/',ViewStaff.as_view(),name="vwstf"),
    path('delstf/<int:sid>',DeleteStaff.as_view(),name="delstf"),
    path('edstf/<int:sid>',EditStaff.as_view(),name="edstf"),
    
]