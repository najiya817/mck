from django.shortcuts import redirect, render
from django.views.generic import View
from .forms import StaffForm
from .models import Staff
from django.utils.decorators import method_decorator

# Create your views here.
def signin_required(fn):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fn(request,*args,**kwargs)
        else:
            return redirect("log")
    return wrapper






@method_decorator(signin_required,name='dispatch')
class MHome(View):
    def get(self,request,*args,**kwargs):
        return render(request,"mhome.html")
    
@method_decorator(signin_required,name='dispatch')
class AddStaff(View):
    def get(self,request,*args,**kwargs):
        f=StaffForm()
        return render(request,"addstaff.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=StaffForm(data=request.POST,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            return redirect("mnh")
        else:
            return render(request,"addstaff.html",{"form":form_data})

@method_decorator(signin_required,name='dispatch')
class ViewStaff(View):
    def get(self,request,*args,**kwargs):
        staff=Staff.objects.all()
        return render(request,"viewstaff.html",{"data":staff})
    
@method_decorator(signin_required,name='dispatch')
class DeleteStaff(View):
    def get(self,request,*args,**kwargs):
        ssid=kwargs.get("sid")
        s=Staff.objects.get(id=ssid)
        s.delete() 
        return redirect("vwstf")
    
          
@method_decorator(signin_required,name='dispatch')
class EditStaff(View):
    def get(self,request,*args,**kwargs):
        ssid=kwargs.get("sid")
        s=Staff.objects.get(id=ssid)
        f=StaffForm(instance=s)
        return render(request,"editstaff.html",{"form":f})
    def post(self,request,*args,**kwargs):
        ssid=kwargs.get("sid")
        s=Staff.objects.get(id=ssid)
        form_data=StaffForm(data=request.POST,files=request.FILES,instance=s)
        if form_data.is_valid():
            form_data.save()
            return redirect("vwstf")
        else:
            return render(request,"editstaff.html",{"form":form_data})
    
