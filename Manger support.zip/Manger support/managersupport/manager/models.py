from django.db import models

# Create your models here.
class Staff(models.Model):
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    dob=models.DateField()
    address=models.CharField(max_length=200)
    email=models.EmailField()
    pic=models.ImageField(upload_to="staff_pic")